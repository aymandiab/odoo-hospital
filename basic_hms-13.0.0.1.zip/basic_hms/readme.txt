
Version 13.0.0.1 :
	- Index improvement.

